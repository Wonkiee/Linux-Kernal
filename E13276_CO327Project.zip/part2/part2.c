#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/sched.h>




MODULE_LICENSE("GPL");
MODULE_AUTHOR("Rajitha Rajasooriya");
MODULE_DESCRIPTION("Involves iterating over all tasks in the system using DFS tree");
MODULE_VERSION("0.1");


void dfs(struct task_struct *task){

	struct task_struct *next;
	struct list_head *list;


	list_for_each( list, &task -> children ) {
		next = list_entry(list, struct task_struct, sibling);
		printk( KERN_INFO "Pid = %d Process Name = %s State = %ld \n", next -> pid, next -> comm, next -> state );
		dfs( next );
	}	
}

int dfs_tree_tasks_init(void){
	printk(KERN_INFO "Loading module...\n");
	dfs( &init_task );
	return 0;
}	

void dfs_tree_tasks_exit(void){
	printk( KERN_INFO "Removing module...\n" );
}

module_init(dfs_tree_tasks_init);
module_exit(dfs_tree_tasks_exit);


